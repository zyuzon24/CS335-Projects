ZACH YUZON
CSCI 335
PROFESSOR STAMOS
April 8, 2018
-----------------------
Part 1: Which parts of your assignment were completed.

All parts of the assignment is completed in my program.

-----------------------
Part 2: Bugs that you encountered.

The main bugs I encountered were segmentation faults. I fixed these in my final version of my program.

These bugs occurred during the Rehash function.


------------------------
Part 3: Complete instructions of how to run your program(s).

1. Make sure that all files are within the same folder as each other.
2. Open the terminal and “cd” into the folder containing the source files.
3. Input “make all” into the terminal.
4. Input “./test_hash_map words.txt <hash_type>” into the terminal where <hash_type> can be replaced by either “quadratic”, “chaining”, or “double”.
5. Input a word to be searched in the map. If it is in the map, it’s adjacent words will be printed out.
6. Input another word to be searched for in the map.  If it is in the map, it’s adjacent words will be printed out.


------------------------
Part 4: The input file (if any) and the output files (if any).

The input file is called:
words.txt

It contains words to be compared to each other to see which ones are adjacent to each other.
